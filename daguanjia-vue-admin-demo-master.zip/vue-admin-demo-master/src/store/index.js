import Vue from 'vue';
import Vuex from 'vuex';
import { Login } from '@/api'
import { setcode } from '@/api/util'


Vue.use(Vuex);

// 需要维护的状态
const state = {
  user:'',
  code:'',
  msg:''
};
const mutations={
    SET_CODE: (state, code) => {
      state.code = code
    },
    SET_MSG: (state, msg) => {
      state.msg = msg
    },
};
const actions = {
 	Loginuser({ commit}, userInfo) {
    return Login(userInfo).then(response => {
        const Data = response.data;
        setcode(Data.data.ok);
        commit('SET_CODE', Data.data.ok);
        commit('SET_MSG', Data.data.msg);
        console.log(Data);
    }).catch(error => {
      	console.log('err');
    })
  }
}


export default new Vuex.Store({
  mutations,
  actions,
  state,
});