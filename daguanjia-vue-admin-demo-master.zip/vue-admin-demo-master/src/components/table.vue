<template>
    <div>
    <el-tree
    :data="data2"
    show-checkbox
    node-key="id"
    :default-expanded-keys="[2, 3]"
    :default-checked-keys="[5]"
    :props="defaultProps">
    </el-tree>
    </div>
</template>

<script>
export default {
  name:'tree',
  data() {
      return {
        data2: [{
          id: 2,
          label: '用户管理',
          children: [{
            id: 5,
            label: '用户列表'
          }, {
            id: 6,
            label: '用户添加'
          }]
         },{
          id: 3,
          label: '商品管理',
          children: [{
            id: 7,
            label: '商品列表'
          }, {
            id: 8,
            label: '商品查询'
          }]
        }],
        defaultProps: {
          children: 'children',
          label: 'label'
        }
    };
  },
  methods:{
      getCheckedKeys() {
        console.log(this.$refs.tree.getCheckedKeys());
      }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>