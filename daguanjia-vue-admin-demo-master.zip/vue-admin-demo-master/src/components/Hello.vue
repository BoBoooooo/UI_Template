<template>
<div class="bullshit">
  <div class="bullshit__oops">欢迎进入!</div>
</div>
</template>

<script>
export default {
  name: 'hello',
  data() {
    return {
      
    }
  },
  methods: {
 
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.bullshit{

}
.bullshit__oops{
    font-size: 32px;
    font-weight: 700;
    line-height: 40px;
    margin-bottom: 20px;
    color: #1482f0;
}
</style>
