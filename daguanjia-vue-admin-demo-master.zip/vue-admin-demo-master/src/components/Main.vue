<template>
<div class="warrp">
   	<div class="header">
   	    <div class="logo">ADMIN</div>
   	    <el-breadcrumb class="crumb" separator="/">
			<el-breadcrumb-item v-for="item in $route.matched" :key="item.path">
				{{ item.name }}
			</el-breadcrumb-item>
		</el-breadcrumb>
   	 	<div class="avater">
   	 	 	<el-dropdown trigger="hover">
          <span class="el-dropdown-link">
            Admin<i class="el-icon-caret-bottom el-icon--right"></i>
          </span>
  				<el-dropdown-menu slot="dropdown">
  					<el-dropdown-item>密码修改</el-dropdown-item>
  					<el-dropdown-item divided @click.native="logout">退出登录</el-dropdown-item>
  				</el-dropdown-menu>
			  </el-dropdown>
   	 	</div>
   	</div>
	<aside class="menu">
	 	<el-menu :default-active="$route.path" class="el-menu-vertical-demo" @open="handleOpen" @close="handleClose" unique-opened router theme="dark">
	      <template v-for="(item,index) in $router.options.routes" v-if="!item.hidden">
				   <el-submenu :index="index+''">
              <template slot="title">{{item.name}}</template>
  			    	  <el-menu-item v-for="child in item.children" :index="child.path" :key="child.path" v-if="!child.hidden">{{child.name}}
                </el-menu-item>
				   </el-submenu>
			  </template>
	  </el-menu>
 	</aside>
   	<section class="main-box">
   	 	<transition name="fade" mode="out-in">
			<router-view></router-view>
		</transition>
   	</section>
</div>
</template>

<script>
export default {
  name: 'Main',
  data() {
    return {

    }
      
  },
  methods: {
	  handleOpen(key, keyPath) {
	    console.log(key, keyPath);
	  },
	  handleClose(key, keyPath) {
	    console.log(key, keyPath);
	  },
    logout(){
      this.$router.push('/');
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.warrp{
	position: absolute;
	top: 0;
    bottom: 0;
    width: 100%;
}
.header{
	height: 60px;
	line-height: 60px;
	padding-right: 20px;
	background-color: #fff;
	border-bottom: 1px solid #d1d4d7;
    box-shadow: 0 0 5px rgba(0,0,0,.1);
}
.avater{
	text-align: right;
    padding-right: 20px;
    float: right;
}
.logo{
	width: 160px;
	text-align: center;
	height: 60px;
    font-size: 22px;
    padding-left: 20px;
    padding-right: 20px;
    float: left;
    border-right: 1px solid #d1d4d7;
}
.crumb{
    display: inline-block;
    font-size: 14px;
    line-height: 60px;
    margin-left: 10px;
    float: left;
}
.avater span{
  font-size: 16px;
}
.main-container{
    overflow: hidden;
}
.menu{
	width: 200px;
	position: absolute;
    z-index: 1000;
    left: 0;
    top: 60px;
    bottom: 0;
    background: #324157;
}
.main-box{
	margin-left: 200px;
	padding: 20px;
}
</style>
