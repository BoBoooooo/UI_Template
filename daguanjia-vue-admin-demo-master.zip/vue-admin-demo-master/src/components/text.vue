<template>
<div>
  <el-form :inline="true" :model="formInline" class="d-inline">
    <el-form-item label="审批人">
      <el-input v-model="formInline.user" placeholder="审批人"></el-input>
    </el-form-item>
    <el-form-item label="活动区域">
      <el-select v-model="formInline.region" placeholder="活动区域">
        <el-option label="区域一" value="shanghai"></el-option>
        <el-option label="区域二" value="beijing"></el-option>
      </el-select>
    </el-form-item><el-form-item>
      <el-button type="primary" @click="onSubmit">查询</el-button>
    </el-form-item>
    </el-form-item><el-form-item>
      <el-button type="primary" @click="add">新增</el-button>
    </el-form-item>
  </el-form>
  <el-table
      :data="tableData"
      style="margin:10px 0">
      <el-table-column
        prop="date"
        align="center"
        label="日期"
        width="180">
      </el-table-column>
      <el-table-column
        prop="name"
        align="center"
        label="姓名"
        width="180">
      </el-table-column>
      <el-table-column
        prop="address"
        align="center"
        label="地址">
      </el-table-column>
      <el-table-column label="操作" align="center">
      <template scope="scope">
        <el-button
          size="small"
          @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
        <el-button
          size="small"
          type="danger"
          @click="handleDelete(scope.$index, scope.row)">删除</el-button>
      </template>
    </el-table-column>
    </el-table>
    <el-pagination
    layout="prev, pager, next"
    :total="total"
    @current-change="handleCurrentChange">
    </el-pagination>
    <!--新增界面-->
    <el-dialog title="新增" v-model="addFormVisible" :close-on-click-modal="false">
      <el-form :model="addForm" label-width="80px" ref="addForm" >
        <el-form-item label="姓名" prop="name">
          <el-input v-model="addForm.name" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="生日">
          <el-date-picker type="date" placeholder="选择日期" v-model="addForm.birth"  class="d-inline"></el-date-picker>
        </el-form-item>
        <el-form-item label="地址">
          <el-input type="textarea" v-model="addForm.addr"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click.native="addFormVisible = false">取消</el-button>
        <el-button type="primary" @click.native="addSubmit">提交</el-button>
      </div>
    </el-dialog>
    <!--编辑界面-->
    <el-dialog title="编辑" v-model="editFormVisible" :close-on-click-modal="false">
      <el-form :model="editForm" label-width="80px" ref="editForm">
        <el-form-item label="姓名" prop="name">
          <el-input v-model="editForm.name" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="生日">
          <el-date-picker type="date" class="d-inline" placeholder="选择日期" v-model="editForm.birth"></el-date-picker>
        </el-form-item>
        <el-form-item label="地址">
          <el-input type="textarea" v-model="editForm.addr"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click.native="editFormVisible = false">取消</el-button>
        <el-button type="primary" @click.native="editSubmit">提交</el-button>
      </div>
    </el-dialog>
</div>
</template>

<script>
import { Login } from '../api/index';
export default {
  name:'table',
  data() {
    return {
      addFormVisible: false,//新增界面是否显示
      editFormVisible: false,
      total:100,
      formInline: {
          user: '',
          region: '',
          page:1,
          pagesize:10
      },
      tableData: [{
        date: '2017-08-02',
        name: '王小虎',
        address: '上海市普陀区金沙江路 1518 弄'
      }, {
        date: '2017-07-04',
        name: '王小虎',
        address: '上海市普陀区金沙江路 1517 弄'
      }, {
        date: '2017-06-01',
        name: '王小虎',
        address: '上海市普陀区金沙江路 1519 弄'
      }, {
        date: '2017-05-03',
        name: '王小虎',
        address: '上海市普陀区金沙江路 1516 弄'
      }],
      addForm: {
          name: '',
          birth: '',
          addr: ''
      },
      editForm: {
          name: '',
          birth: '',
          addr: ''
      }
    }
  },
  methods:{
      handleEdit(index, row) {
        this.editFormVisible = true;
        console.log(index, row);
      },
      handleDelete(index, row) {
        console.log(index, row);
        this.$confirm('确认删除该记录吗?', '提示', {
          type: 'warning'
        }).then(() => {
          let params = { id: row.id };
          Login(params).then((res) => {
            this.$message({
              message: '删除成功',
              type: 'success'
            });
            // this.getlist();
          });
        }).catch(() => {

        });
      },
      onSubmit() {
        this.formInline.page=1;
        console.log(this.formInline);
      },
      //打开新增页面
      add(){
        console.log("ok");
        this.addFormVisible = true;
      },
      //新增
      addSubmit(){
        console.log(this.addForm);
      },
      editSubmit(){
        console.log(this.editForm);
      },
      handleCurrentChange(val) {
        this.formInline.page=val;
        console.log(this.formInline);
      }

  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.d-inline{
  float: left;
}
</style>