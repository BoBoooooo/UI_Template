<template>
<div class="login-container">
  <div class="login-box">
    <h3>后台系统</h3>
    <el-form :rules="rules" ref="loginform" :model="loginform">
      <el-form-item prop="view">
        <el-input  v-model="loginform.view" placeholder="用户名"></el-input>
      </el-form-item>
      <el-form-item prop="book">
        <el-input type="password" v-model="loginform.book" placeholder="密码" auto-complete="off"></el-input>
      </el-form-item>
      <el-button type="primary" style="width:100%;" @click="submitForm('loginform')">提交</el-button>
    </el-form>
  </div>
</div>
</template>
<script>
export default {
  name: 'Login',
  data() {
    return {
      loginform: {
        view: '',
        book:''
      },
      rules: {
        view: [
          { required: true, message: '请输入活动名称', trigger: 'blur' }
        ],
        book: [
          { required: true, message: '请输入密码', trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
   submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {          
          this.$store.dispatch('Loginuser',this.loginform).then(() => {
            this.$notify.info({
              title: '登录消息',
              message: this.$store.state.msg,
              duration:1000
            });
            setTimeout(() => {
              this.$router.push({ path: '/admin' });
            }, 1200)
          }).catch(() => {
            console.log('err2')
          })
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.login-container{
    position: relative;
    width: 100%;
    height: 100%;
    height:100vh;
    background-color: #2d3a4b;
}
.login-box{
    position: absolute;
    left: 0;
    right: 0;
    width: 400px;
    padding: 0px 35px 15px;
    margin: 200px auto;
    background-color: #fff;
    box-shadow: 0 0 10px #cac6c6;
}
</style>
