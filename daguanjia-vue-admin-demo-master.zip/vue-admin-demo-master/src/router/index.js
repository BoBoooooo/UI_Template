import Vue from 'vue'
import Router from 'vue-router'
import Login from '@/components/Login'
import Hello from '@/components/Hello'
import Main from '@/components/Main'
import text from '@/components/text'
import tables from '@/components/table'

Vue.use(Router)

const router = new Router({
  mode: 'history',
   routes: [
    {
      path: '/',
      name: '',
      component: Login,
      hidden: true
    },
    {
      path: '/',
      name: '用户管理',
      component: Main,
      meta: { role: ['1'] },
      children: [
        { path: '/admin', component:Hello,name: 'Hello',hidden: true},
        { path: '/admin/table', component:text,name: '用户列表'},
        { path: '/admin/tables', component:tables,name: '用户添加'},
      ]
    },
    {
      path: '/',
      name: '游戏包管理',
      component: Main,
      children: [
        { path: '/c/table1', component:text,name: '游戏包查询'},
      ]
    }
  ]
})
router.beforeEach((to, from, next) => {
  let hasLogin = localStorage.getItem("code");
  // console.log(hasLogin)
  if (to.path === '/') {
    next()
  } else {
    if (hasLogin === 'false') {
      // 跳转到登录页
      next({path: '/'})
    } else {
      next(); 
    }
  }
});


export default router;