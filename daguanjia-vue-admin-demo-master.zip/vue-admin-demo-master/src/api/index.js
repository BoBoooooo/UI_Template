import axios from 'axios';
axios.defaults.baseURL = 'http://novel.juhe.im';
// axios.defaults.withCredentials = true;
axios.defaults.timeout = 5000;
axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=UTF-8';

export function Login (params = {}){ 
	return axios.get('/book-sources', { params: params });
};


